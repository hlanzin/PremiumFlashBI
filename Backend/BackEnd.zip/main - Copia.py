from contextlib import asynccontextmanager
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from routers import auth, faturamento, estoque, dist_numerica

@asynccontextmanager
async def lifespan(app: FastAPI):
    print("Flash BI API v1.1.0 iniciada")
    yield

app = FastAPI(title="Flash BI API", version="1.1.0", lifespan=lifespan)
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_credentials=True,
                   allow_methods=["*"], allow_headers=["*"])

app.include_router(auth.router)
app.include_router(faturamento.router)
app.include_router(estoque.router)
app.include_router(dist_numerica.router)

@app.get("/", tags=["Status"])
def root():
    return {"status": "ok", "versao": "1.1.0", "docs": "/docs"}
